const { Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, Events, AttachmentBuilder } = require('discord.js');
const config = require('./config.json');
const path = require('path');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages
  ],
  partials: ['CHANNEL'],
});

client.once('ready', () => {
  console.log(`Bot is online as ${client.user.tag}`);
});

client.on('messageCreate', async (message) => {
  if (!message.content.startsWith(config.prefix) || message.author.bot) return;

  const args = message.content.slice(config.prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'promo') {
    const [link, coupon, usage, imageFilename] = args;

    if (!link || !coupon || !usage) {
      return message.reply('Correct usage: `!promo <link> <coupon> <usage> [imageFilename]`');
    }

    try {
      await message.delete();
    } catch (error) {
      console.log('Could not delete message:', error);
    }

    const embed = new EmbedBuilder()
      .setTitle('🔗 Click Here')
      .setURL(link)
      .setDescription(`Coupon: \`XXXXX\`\nUsage: ${usage}\nMore Details: ${config.defaultSite}`)
      .setColor(0x2ecc71);

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`copy_coupon_${coupon}`)
        .setLabel('🎟️ Get Coupon')
        .setStyle(ButtonStyle.Primary)
    );

    const filesArr = [];
    if (imageFilename) {
      const imagePath = path.join(__dirname, 'image', imageFilename);
      const attachment = new AttachmentBuilder(imagePath, { name: imageFilename });
      embed.setImage(`attachment://${imageFilename}`);
      filesArr.push(attachment);
    }

    await message.channel.send({ embeds: [embed], components: [row], files: filesArr });
  }
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isButton()) return;

  const id = interaction.customId;
  if (id.startsWith('copy_coupon_')) {
    const coupon = id.replace('copy_coupon_', '');

    try {
      await interaction.user.send(`🎟️ Your coupon is: **${coupon}**`);
      await interaction.reply({ content: 'Coupon sent to your DM! 📬', ephemeral: true });
    } catch (error) {
      await interaction.reply({ content: "Couldn't DM you. Please check your privacy settings!", ephemeral: true });
    }
  }
});
const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

app.get("/", (req, res) => {
  res.send("Bot is running!");
});

app.listen(port, () => {
  console.log(`Web server is live on port ${port}`);
});
client.login(config.token);
